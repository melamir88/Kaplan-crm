import CRM from "../components/CRM";

export default function Home() {
  return <CRM />;
}
