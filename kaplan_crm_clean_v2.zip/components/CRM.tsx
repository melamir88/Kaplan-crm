export default function CRM() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Welcome to Kaplan CRM</h1>
      <p>This is your live CRM prototype, ready to be customized.</p>
    </div>
  );
}
